﻿Module ConstModule01
  Private Const DEFAULT_ACTIVE As Boolean = True
  Private Const DEFAULT_LIST_PRICE As Decimal = 999.99D

  Sub Sample01()
    Dim isActive As Boolean = DEFAULT_ACTIVE
    Dim Name As String = "10 Speed Bike"
    Dim ListPrice As Decimal

    ListPrice = DEFAULT_LIST_PRICE
  End Sub
End Module
