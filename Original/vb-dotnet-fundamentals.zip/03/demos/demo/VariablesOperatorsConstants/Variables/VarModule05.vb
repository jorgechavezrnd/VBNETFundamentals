﻿Option Strict Off

Module VarModule05
  Sub NumericStrings()
    Dim s1 As Object
    Dim s2 As Object

    s1 = "1"
    s2 = 2
    Console.WriteLine(s1 + s2)

    s2 = "2"
    Console.WriteLine(s1 + s2)
  End Sub
End Module
