﻿Collection Samples
==================================

\Array Folder
----------------------------
ArraySample01 - Declare and fill an array
ArraySample02 - Another way to declare and fill an array

\ArrayList Folder
----------------------------
ArrayListSample01 - Declare and fill an ArrayList
ArrayListSample02 - Create ArrayList of products

\Dictionary Folder
----------------------------
DictionarySample01 - Creating a dictionary
DictionarySample02 - Using ContainsKey()
DictionarySample03 - Using Count(), Remove() and Clear()
DictionarySample03 - Using Sum(), Average(), Min() and Max()

List(Of T)
----------------------------
ListSample01 - Creating a List(Of Product)
ListSample02 - Using Exists()
ListSample03 - Using Count(), RemoveAt() and Clear()
ListSample04 - Using Sum(), Average(), Min() and Max()
