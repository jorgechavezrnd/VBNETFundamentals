﻿Namespace PropertySample02
  Public Class Product
    Public Property IsActive As Boolean
    Public Property Name As String
    Public Property ProductNumber As String
  End Class
End Namespace
