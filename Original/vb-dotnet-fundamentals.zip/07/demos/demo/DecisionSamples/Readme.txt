﻿Decision Samples
==================================

\Looping Folder
----------------------------
LoopingSample01 - Do While
LoopingSample02 - Loop While
LoopingSample03 - Do Until
LoopingSample04 - Loop Until
LoopingSample05 - For Next
LoopingSample06 - For Next Step


\IfStatments Folder
----------------------------
IfSample01 - If Then
IfSample02 - If Then Else
IfSample03 - If Then ElseIf


\CaseStatements Folder
----------------------------
CaseSample01 - Select Case
CaseSample02 - Select Case Else


\Other Folder
----------------------------
OtherSample01 - Compiler Constants
OtherSample02 - Custom Compiler Constants
OtherSample03 - With...End With / #Region